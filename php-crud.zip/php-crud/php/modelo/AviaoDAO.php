<?php 

    include_once("Aviao.php");
    include_once("../bd/Database.php");

    class AviaoDAO {
        public function __construct() {}

        public function create(Aviao $aviao){
            $dao = new Database();
            $conn = $dao->getConnection();

            $sql = 'INSERT INTO aviao (nome, qtd_litro, ano, url_image) VALUES (:nome, :qtd_litro, :ano, :url_image);';
            $stmt = $conn->prepare($sql);

            $nome = $aviao->getNome();
            $qtd_litro = $aviao->getQtdLitro();
            $ano = $aviao->getAno();
            $url_image = $aviao->getImagem();
            
            $stmt->bindValue(':nome', $nome);
            $stmt->bindValue(':qtd_litro', $qtd_litro);
            $stmt->bindValue(':ano', $ano);
            $stmt->bindValue(':url_image', $url_image);
        
            return $stmt->execute();

        }

        public function update(Aviao $aviao){
            $dao = new Database();
            $conn = $dao->getConnection();
        
            $sql = 'UPDATE aviao SET nome = :nome, qtd_litro = :qtd_litro, ano = :ano, url_image = :url_image WHERE id = :id;';
        
            try {
                $stmt = $conn->prepare($sql);
                
                $stmt->bindValue(':id', (int)$aviao->getId());
                $stmt->bindValue(':nome', $aviao->getNome());
                $stmt->bindValue(':qtd_litro', $aviao->getQtdLitro());
                $stmt->bindValue(':ano', $aviao->getAno());
                $stmt->bindValue(':url_image', $aviao->getImagem());
                
                $stmt->execute();
            } catch (PDOException $e) {
                // Captura e trata a exceção aqui
                echo "Erro ao executar a consulta: " . $e->getMessage();
            }
        }

        public function delete($id){
            $dao = new Database();
            $conn = $dao->getConnection();

            $sql = 'DELETE FROM aviao WHERE id = ?';
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
        }

        public function read(){
            $dao = new Database();
            $conn = $dao->getConnection(); 

            $sql = 'SELECT * FROM aviao';
            $stmt = $conn->prepare($sql);
            $stmt->execute();

            if($stmt->rowCount() > 0){
                $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
                return $resultado;
            }else{
                return [];
            }
        }

        public function search($id){
            $dao = new Database();
            $conn = $dao->getConnection(); 
        
            $sql = 'SELECT * FROM aviao WHERE id = ?';
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            
            if($stmt->rowCount() > 0){
                $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                $aviao = new Aviao();

                $aviao->setAll(
                    $resultado['id'],
                    $resultado['nome'],
                    $resultado['qtd_litro'],
                    $resultado['url_image'],
                    $resultado['ano']
                );
        
                return $aviao;
            } else {
                return null; 
            }
        }

    }

?>