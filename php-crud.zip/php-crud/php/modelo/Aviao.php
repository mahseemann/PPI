<?php
     class Aviao{
        public $id;
        public $nome;
        public $qtd_litro;
        public $ano;
        public $url_image;

        public function setAll($id, $nome, $qtd_litro, $url_image, $ano){
            $this->id = $id;
            $this->nome = $nome;
            $this->qtd_litro = $qtd_litro;
            $this->ano = $ano;
            $this->url_image = $url_image;
        }

        public function setAllNoId($nome, $qtd_litro, $url_image, $ano){                                                                                 
            $this->nome = $nome;
            $this->qtd_litro = $qtd_litro;
            $this->ano = $ano;
            $this->url_image = $url_image;
        }
        
        public function __construct(){}

        public function getId(){
            return $this->id;
        }
        public function getNome(){
            return $this->nome;
        }
        public function getQtdLitro(){
            return $this->qtd_litro;
        }
        public function getImagem(){
            return $this->url_image;
        }
        public function getAno(){
            return $this->ano;
        }
        
        
    }
?>