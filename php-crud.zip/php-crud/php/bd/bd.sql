create database if not exists crud;
use crud;

create table aviao(
    id int not null auto_increment,
    nome varchar(255) not null,
    qtd_litros varchar(255) not null not null,
    ano varchar(255) not null not null,
    url_image TEXT not null,
    primary key(id)
);

create table pessoa(
    id int not null auto_increment,
    nome varchar(255) not null,
    cpf varchar(255) not null,
    primary key(id)
);
