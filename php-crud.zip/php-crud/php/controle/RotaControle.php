<?php 

    include_once("AviaoControle.php");
    include_once("../modelo/Aviao.php");

    if(!isset($_POST['op'])){
        echo("Erro parametro não passado");
        exit();
    }

    $op = $_POST['op'];

    switch($op){
        case 'cadastrar':
            if(!isset($_POST['nome']) || !isset($_POST['qtd_litro']) || !isset($_POST['ano']) || !isset($_POST['url_image'])){
                echo("Erro ao cadastrar, alguns parâmetros inválidos");
                exit();
            }
            
            $nome = $_POST['nome'];
            $qtd_litro = $_POST['qtd_litro'];
            $ano = $_POST['ano'];
            $url_image = $_POST['url_image'];
            
           
            $aviaoControle = new AviaoControle();
            $aviaoControle->cadastrarAviao($nome, $qtd_litro, $url_image, $ano);
            header('Location: ../visao/view_listagem.php');

        break;
        case 'atualizar':
            if(!isset($_POST['id']) || !isset($_POST['nome']) || !isset($_POST['qtd_litro']) || !isset($_POST['ano']) || !isset($_POST['url_image'])){
             
                echo("Erro ao atualizar! algumas informaçãoes faltaram");
             exit();
            }
            $id = $_POST['id'];
            $nome = $_POST['nome'];
            $qtd_litro = $_POST['qtd_litro'];
            $ano = $_POST['ano'];
            $url_image = $_POST['url_image'];
            $aviaoControle = new AviaoControle();
            $aviaoControle->editarAviao($id, $nome, $qtd_litro, $url_image, $ano);
            header('Location: ../visao/view_listagem.php');

        break;
        case 'excluir':
            if(!isset($_POST['id'])){
                echo("Erro ao excluir!");
                exit();
            }
            
            $id = $_POST['id'];
            $aviaoControle = new AviaoControle();
            $aviaoControle->excluirAviao($id);
            header('Location: ../visao/view_listagem.php');
        break;
    }
    
?>