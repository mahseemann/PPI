<?php 

    include_once("../modelo/Aviao.php");
    include_once("../modelo/AviaoDAO.php");

    class AviaoControle {
        public function __construct() {}

        public function cadastrarAviao($nome, $qtd_litro, $url_image, $ano){
            // Validação dos dados
            $aviao = new Aviao();
            $aviao->setAllNoId($nome, $qtd_litro, $url_image, $ano);

            $aviaoDAO = new AviaoDAO();
            return $aviaoDAO->create($aviao);
        }

        public function listarAviao(){                                                                                                        
            $aviaoDAO = new AviaoDAO();
            $avioes = $aviaoDAO->read();
            return $avioes;
        }

        public function editarAviao($id, $nome, $qtd_litro, $url_image, $ano){
            $aviao = new Aviao();
            $aviao->setAll($id, $nome, $qtd_litro, $url_image, $ano);
            $aviaoDAO = new AviaoDAO();
            $aviaoDAO->update($aviao);
        }

        public function excluirAviao($id){
            $aviaoDAO = new AviaoDAO();
            $aviaoDAO->delete($id);
        }

        public function getAviao($id){
            $aviaoDAO = new AviaoDAO();
            $aviao = $aviaoDAO->search($id);
            return $aviao;
        }
    }
?>