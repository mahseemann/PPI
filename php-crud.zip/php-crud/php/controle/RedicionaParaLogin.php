<?php
    session_start();

    if (!isset($_SESSION['pessoa'])) {
        header("Location: http://localhost:8080/PHP-CRUD/php/visao/view_login.php");
        exit;
    }
?>