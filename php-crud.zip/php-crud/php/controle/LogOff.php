<?php
    session_start();

    if (isset($_SESSION['pessoa'])) {
        session_destroy();
        header("Location: http://localhost:8080/php-crud/php/visao/view_login.php");
        exit;
    }
    else{
        header("Location: http://localhost:8080/php-crud/php/visao/view_login.php");
        exit;
    }
?>