<?php include_once "../controle/RedicionaParaLogin.php"?>
<?php include_once "../../css/bootstrap.php"?>
<?php include_once "../../css/header.php"?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aviações Mah Seeman</title>
</head>
<body class="bg-light">
<div class="container mt-5 text-center">
        <h1 class="mb-4">Aviações Mah Seeman</h1>
        <a href="view_listagem.php" class="btn btn-primary mr-2">Página de Listagem</a>
        <a href="view_cadastro.php" class="btn btn-primary">Página de Cadastro</a>
    </div>
    <div class="d-flex justify-content-center mt-4 ">

        <img src="https://revistaazul.voeazul.com.br/wp-content/uploads/2020/08/Screen-Shot-2020-08-03-at-15.08.40.png" alt="Avião Azul">
    </div>
</body>
</html>

<?php include_once "../../CSS/footer.php"?>