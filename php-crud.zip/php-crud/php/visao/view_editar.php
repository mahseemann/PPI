<?php include_once "../controle/RedicionaParaLogin.php"?>
<?php include_once "../../css/bootstrap.php"?>
<?php include_once "../../css/header.php"?>

<?php
    include_once "../controle/AviaoControle.php";
    include_once "../modelo/Aviao.php";
    
    if(!isset($_GET['id'])){
        echo("Erro: parâmetro não passado");
        exit();
    }
    $id = $_GET['id'];
    $aviaoController = new AviaoControle();
    $aviao = $aviaoController->getAviao($id);

    if ($aviao == null) {
        echo("Erro ao buscar fruta");
        exit();
    }
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action='../CONTROL/RotaPostController.php' method='POST'>
                <input type='hidden' name='op' value='atualizar'>
                <div class="text-center mb-4">
                    <img src='<?php echo $aviao->getImagem(); ?>' alt='Figura' class="img-fluid rounded">
                </div>
                <div class="mb-3">
                    <label for='id'>Id</label>
                    <input type='hidden' name='id' value='<?php echo $aviao->getId(); ?>'>
                </div>
                <div class="mb-3">
                    <label for='nome'>Nome</label>
                    <input type='text' name='nome' value='<?php echo $aviao->getNome(); ?>' class="form-control">
                </div>
                <div class="mb-3">
                    <label for='descricao'>Descrição</label>
                    <input type='text' name='qtd_litro' value='<?php echo $aviao->getQtdLitro(); ?>' class="form-control">
                </div>
                <div class="mb-3">
                    <label for='quantidade'>Ano</label>
                    <input type='text' name='ano' value='<?php echo $aviao->getAno(); ?>' class="form-control">
                </div>
                <div class="mb-3">
                    <label for='url_image'>URL da Imagem</label>
                    <input type='text' name='url_image' value='<?php echo $aviao->getImagem(); ?>' class="form-control">
                </div>
                <div class="mb-3">
                    <input type='submit' value='Atualizar' class='btn btn-primary'>
                    <a href='view_listagem.php' class='btn btn-secondary'>Cancelar</a>
                </div>
            </form>

            <!-- Formulário para exclusão -->
            <form action='../controle/RotaControle.php' method='POST'>
                <input type='hidden' name='op' value='excluir'>
                <input type='hidden' name='id' value='<?php echo $aviao->getId(); ?>'>
                <input type='submit' value='Excluir' class='btn btn-danger'>
            </form>
        </div>
    </div>
</div>

<?php include_once "../../css/footer.php"?>
