<?php include_once "../../css/bootstrap.php"?>
<?php include_once "../../css/header.php"?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="../controle/RotaControle.php" method="post">
                <div class="mb-3">
                    <input type="text" name="nome" placeholder="Digite o nome" class="form-control">
                </div>
                <div class="mb-3">
                    <input type="text" name="qtd_litro" placeholder="Digite a Quantidade Litros" class="form-control">
                </div>
                <div class="mb-3">
                    <input type="text" name="ano" placeholder="Digite o Ano" class="form-control">
                </div>
                <div class="mb-3">
                    <input type="text" name="url_image" placeholder="URL da Imagem" class="form-control">
                </div>
                <input type="text" name="op" value="cadastrar" hidden>
                <div class="mb-3">
                    <input type="submit" value="Cadastrar" class="btn btn-primary">
                </div>
            </form>
            <div class="mb-3">
                <a href="view_listagem.php" class="btn btn-secondary">Página de Listagem</a>
            </div>
        </div>
    </div>
</div>

<?php include_once "../../CSS/footer.php"?>